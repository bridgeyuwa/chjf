<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['nav']));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['nav']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>

<div
    x-data="mobileNav"
    x-show="open"
    x-cloak
    class="fixed inset-0 z-[60] lg:hidden"
    aria-modal="true"
    role="dialog"
>
    
    <div
        x-show="open"
        x-transition:enter="transition ease-out duration-200"
        x-transition:enter-start="opacity-0"
        x-transition:enter-end="opacity-100"
        x-transition:leave="transition ease-in duration-150"
        x-transition:leave-start="opacity-100"
        x-transition:leave-end="opacity-0"
        @click="close()"
        class="absolute inset-0 bg-stone-900/40 backdrop-blur-sm"
    ></div>

    
    <div
        x-show="open"
        x-transition:enter="transition ease-out duration-300"
        x-transition:enter-start="translate-x-full"
        x-transition:enter-end="translate-x-0"
        x-transition:leave="transition ease-in duration-200"
        x-transition:leave-start="translate-x-0"
        x-transition:leave-end="translate-x-full"
        class="absolute right-0 top-0 flex h-full w-full max-w-sm flex-col bg-white shadow-2xl"
    >
        
        <div class="flex items-center justify-between border-b border-stone-200 px-5 py-4">
            <span class="font-display text-base font-semibold text-stone-900">Menu</span>
            <button @click="close()" class="inline-flex h-9 w-9 items-center justify-center rounded-lg text-stone-500 hover:bg-stone-100" aria-label="Close menu">
                <svg class="h-5 w-5" fill="none" stroke="currentColor" viewBox="0 0 24 24" stroke-width="2">
                    <path stroke-linecap="round" stroke-linejoin="round" d="M6 18L18 6M6 6l12 12"></path>
                </svg>
            </button>
        </div>

        
        <nav class="flex-1 overflow-y-auto px-3 py-4" aria-label="Mobile">
            <ul class="space-y-1">
                <?php $__currentLoopData = $nav; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li>
                        <?php if(isset($item['children'])): ?>
                            <div x-data="{ expanded: $persist(false) }">
                                <button
                                    @click="expanded = !expanded"
                                    class="flex w-full items-center justify-between rounded-lg px-3 py-2.5 text-left text-base font-medium text-stone-800 hover:bg-brand-50"
                                    :aria-expanded="expanded"
                                >
                                    <span><?php echo e($item['label']); ?></span>
                                    <svg class="h-4 w-4 transition-transform text-stone-400" :class="expanded ? 'rotate-180' : ''" fill="none" stroke="currentColor" viewBox="0 0 24 24" stroke-width="2.5">
                                        <path stroke-linecap="round" stroke-linejoin="round" d="M19 9l-7 7-7-7"></path>
                                    </svg>
                                </button>
                                <div
                                    x-show="expanded"
                                    x-collapse
                                    class="ml-3 mt-1 border-l border-stone-200 pl-3"
                                >
                                    <a href="<?php echo e($item['route']); ?>" class="block rounded-lg px-3 py-2 text-sm font-medium text-brand-700 hover:bg-brand-50">
                                        View all <?php echo e($item['label']); ?> →
                                    </a>
                                    <?php $__currentLoopData = $item['children']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $child): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <a href="<?php echo e($child['route']); ?>" class="block rounded-lg px-3 py-2 text-sm text-stone-700 hover:bg-brand-50 hover:text-brand-800">
                                            <?php echo e($child['label']); ?>

                                        </a>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                            </div>
                        <?php else: ?>
                            <a href="<?php echo e($item['route']); ?>" class="block rounded-lg px-3 py-2.5 text-base font-medium text-stone-800 hover:bg-brand-50 hover:text-brand-800">
                                <?php echo e($item['label']); ?>

                            </a>
                        <?php endif; ?>
                    </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </nav>

        
        <div class="border-t border-stone-200 p-5 space-y-2">
            <a href="<?php echo e(route('get-involved.donate')); ?>" class="flex w-full items-center justify-center gap-2 rounded-lg bg-brand-600 px-4 py-3 text-sm font-semibold text-white shadow-soft hover:bg-brand-700">
                <svg class="h-4 w-4" fill="none" stroke="currentColor" viewBox="0 0 24 24" stroke-width="2">
                    <path stroke-linecap="round" stroke-linejoin="round" d="M21 8.25c0-2.485-2.099-4.5-4.688-4.5-1.935 0-3.597 1.126-4.312 2.733-.715-1.607-2.377-2.733-4.313-2.733C5.1 3.75 3 5.765 3 8.25c0 7.22 9 12 9 12s9-4.78 9-12z"></path>
                </svg>
                Donate Now
            </a>
            <a href="<?php echo e(route('get-involved.volunteer')); ?>" class="flex w-full items-center justify-center gap-2 rounded-lg bg-white px-4 py-3 text-sm font-semibold text-brand-700 ring-1 ring-brand-200 hover:bg-brand-50">
                Become a Volunteer
            </a>
        </div>
    </div>
</div>
<?php /**PATH C:\Users\Bridges\Herd\chj\resources\views/components/nav/mobile-nav.blade.php ENDPATH**/ ?>
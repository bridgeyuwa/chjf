
<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames(([
    'eyebrow' => null,
    'title' => null,
    'intro' => null,
]));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter(([
    'eyebrow' => null,
    'title' => null,
    'intro' => null,
]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>

<section class="relative overflow-hidden bg-gradient-to-br from-brand-800 via-brand-700 to-brand-900">
    
    <div class="absolute -right-24 -top-24 h-72 w-72 rounded-full bg-brand-500/30 blur-3xl"></div>
    <div class="absolute -bottom-32 -left-24 h-72 w-72 rounded-full bg-spark-500/15 blur-3xl"></div>

    <div class="container-prose relative py-14 sm:py-20 lg:py-24">
        <div class="max-w-3xl">
            <?php if($eyebrow): ?>
                <span class="inline-flex items-center gap-2 rounded-full bg-white/10 px-3 py-1 text-xs font-semibold uppercase tracking-widest text-brand-100 ring-1 ring-inset ring-white/15">
                    <span class="h-1.5 w-1.5 rounded-full bg-spark-400"></span>
                    <?php echo e($eyebrow); ?>

                </span>
            <?php endif; ?>
            <?php if($title): ?>
                <h1 class="mt-5 font-display text-4xl font-semibold tracking-tight text-white sm:text-5xl lg:text-6xl">
                    <?php echo e($title); ?>

                </h1>
            <?php endif; ?>
            <?php if($intro): ?>
                <p class="mt-5 text-lg leading-relaxed text-brand-100 sm:text-xl"><?php echo e($intro); ?></p>
            <?php endif; ?>
            <?php if(isset($actions)): ?>
                <div class="mt-8 flex flex-wrap gap-3">
                    <?php echo e($actions); ?>

                </div>
            <?php endif; ?>
        </div>
    </div>
</section>
<?php /**PATH C:\Users\Bridges\Herd\chj\resources\views/components/ui/page-hero.blade.php ENDPATH**/ ?>
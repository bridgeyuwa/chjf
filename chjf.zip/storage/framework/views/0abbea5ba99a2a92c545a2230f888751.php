<?php $__env->startSection('content'); ?>

<?php if (isset($component)) { $__componentOriginalc2ac24e8b26a95c4ab17f6ffff7eecc8 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalc2ac24e8b26a95c4ab17f6ffff7eecc8 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.ui.page-hero','data' => ['eyebrow' => 'Stories & News','title' => 'Dispatches from the work.','intro' => 'Real stories from the people we serve, the volunteers who serve them, and the staff who walk alongside. Plus news, updates, and reflections on faith in action.']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('ui.page-hero'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['eyebrow' => 'Stories & News','title' => 'Dispatches from the work.','intro' => 'Real stories from the people we serve, the volunteers who serve them, and the staff who walk alongside. Plus news, updates, and reflections on faith in action.']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalc2ac24e8b26a95c4ab17f6ffff7eecc8)): ?>
<?php $attributes = $__attributesOriginalc2ac24e8b26a95c4ab17f6ffff7eecc8; ?>
<?php unset($__attributesOriginalc2ac24e8b26a95c4ab17f6ffff7eecc8); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc2ac24e8b26a95c4ab17f6ffff7eecc8)): ?>
<?php $component = $__componentOriginalc2ac24e8b26a95c4ab17f6ffff7eecc8; ?>
<?php unset($__componentOriginalc2ac24e8b26a95c4ab17f6ffff7eecc8); ?>
<?php endif; ?>

<?php if (isset($component)) { $__componentOriginal386dc8449d6925e995096d9b8aa1f23d = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal386dc8449d6925e995096d9b8aa1f23d = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.ui.section','data' => ['bg' => 'white','spacing' => 'default']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('ui.section'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['bg' => 'white','spacing' => 'default']); ?>
    <div class="container-prose">

        
        <div class="flex flex-wrap items-center justify-between gap-4 border-b border-stone-200 pb-6">
            <div class="flex flex-wrap gap-2">
                <?php $__currentLoopData = ['All', 'Stories', 'News', 'Reflections', 'Programs', 'Volunteers']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <a href="?category=<?php echo e(strtolower($cat)); ?>"
                       class="rounded-full px-3 py-1.5 text-xs font-semibold uppercase tracking-widest transition-colors
                       <?php if(request('category', 'all') === strtolower($cat) || ($i === 0 && !request('category'))): ?>
                           bg-brand-600 text-white shadow-soft
                       <?php else: ?>
                           bg-stone-100 text-stone-700 hover:bg-brand-100 hover:text-brand-700
                       <?php endif; ?>">
                        <?php echo e($cat); ?>

                    </a>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <p class="text-xs text-stone-500"><?php echo e($posts->total() ?? count($posts)); ?> stories</p>
        </div>

        
        <?php if(isset($posts[0])): ?>
            <?php $featured = $posts[0]; ?>
            <article class="mt-10 grid gap-8 lg:grid-cols-2 lg:gap-12 items-center">
                <a href="<?php echo e(route('blog.show', $featured)); ?>" class="group block overflow-hidden rounded-2xl shadow-lifted">
                    <div class="aspect-[16/9] overflow-hidden">
                        <img src="<?php echo e($featured->featured_image ?? 'https://images.unsplash.com/photo-1593113598332-cd288d649433?ixlib=rb-4.0.3&auto=format&fit=crop&w=1200&q=80'); ?>"
                             alt="<?php echo e($featured->title); ?>"
                             class="h-full w-full object-cover transition-transform duration-500 group-hover:scale-105"
                             loading="lazy"/>
                    </div>
                </a>
                <div>
                    <span class="inline-flex items-center gap-2 rounded-full bg-brand-50 px-3 py-1 text-xs font-semibold uppercase tracking-widest text-brand-700 ring-1 ring-inset ring-brand-200">
                        <span class="h-1.5 w-1.5 rounded-full bg-spark-400"></span>
                        Featured · <?php echo e($featured->category ?? 'Story'); ?>

                    </span>
                    <h2 class="mt-4 font-display text-3xl font-semibold tracking-tight text-stone-900 sm:text-4xl">
                        <a href="<?php echo e(route('blog.show', $featured)); ?>" class="hover:text-brand-700"><?php echo e($featured->title); ?></a>
                    </h2>
                    <p class="mt-4 text-base leading-relaxed text-stone-600"><?php echo e($featured->excerpt); ?></p>
                    <div class="mt-5 flex items-center gap-3 text-sm">
                        <span class="font-medium text-stone-800"><?php echo e($featured->author ?? 'CHJ Team'); ?></span>
                        <span class="text-stone-400">·</span>
                        <span class="text-stone-500"><?php echo e(isset($featured->published_at) ? $featured->published_at->format('j F Y') : date('j F Y')); ?></span>
                        <span class="text-stone-400">·</span>
                        <span class="text-stone-500"><?php echo e($featured->reading_time ?? 4); ?> min read</span>
                    </div>
                    <div class="mt-6">
                        <?php if (isset($component)) { $__componentOriginala8bb031a483a05f647cb99ed3a469847 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginala8bb031a483a05f647cb99ed3a469847 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.ui.button','data' => ['variant' => 'outline','href' => ''.e(route('blog.show', $featured)).'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('ui.button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['variant' => 'outline','href' => ''.e(route('blog.show', $featured)).'']); ?>Read story <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginala8bb031a483a05f647cb99ed3a469847)): ?>
<?php $attributes = $__attributesOriginala8bb031a483a05f647cb99ed3a469847; ?>
<?php unset($__attributesOriginala8bb031a483a05f647cb99ed3a469847); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala8bb031a483a05f647cb99ed3a469847)): ?>
<?php $component = $__componentOriginala8bb031a483a05f647cb99ed3a469847; ?>
<?php unset($__componentOriginala8bb031a483a05f647cb99ed3a469847); ?>
<?php endif; ?>
                    </div>
                </div>
            </article>
        <?php endif; ?>

        
        <?php if(count($posts) > 1): ?>
            <div class="mt-16 grid gap-8 sm:grid-cols-2 lg:grid-cols-3">
                <?php $gridPosts = array_slice($posts->items() ?? $posts, 1); ?>
                <?php $__currentLoopData = $gridPosts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <article
                        x-data="reveal(<?php echo e($i * 60); ?>)"
                        x-intersect.once="onIntersect()"
                        class="fade-up flex flex-col"
                    >
                        <a href="<?php echo e(route('blog.show', $post)); ?>" class="group block overflow-hidden rounded-2xl shadow-card ring-1 ring-stone-200/60 transition-all hover:shadow-lifted">
                            <div class="aspect-[3/2] overflow-hidden">
                                <img src="<?php echo e($post->featured_image ?? 'https://images.unsplash.com/photo-1488521787991-ed7bbaae773c?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&q=80'); ?>"
                                     alt="<?php echo e($post->title); ?>"
                                     class="h-full w-full object-cover transition-transform duration-500 group-hover:scale-105"
                                     loading="lazy"/>
                            </div>
                            <div class="flex flex-1 flex-col p-6">
                                <span class="text-[10px] font-semibold uppercase tracking-widest text-brand-700"><?php echo e($post->category ?? 'Story'); ?></span>
                                <h3 class="mt-2 font-display text-lg font-semibold text-stone-900 group-hover:text-brand-700"><?php echo e($post->title); ?></h3>
                                <p class="mt-2 flex-1 text-sm leading-relaxed text-stone-600"><?php echo e($post->excerpt); ?></p>
                                <div class="mt-4 flex items-center justify-between text-xs text-stone-500 border-t border-stone-100 pt-4">
                                    <span><?php echo e(isset($post->published_at) ? $post->published_at->format('j M Y') : date('j M Y')); ?></span>
                                    <span><?php echo e($post->reading_time ?? 4); ?> min read</span>
                                </div>
                            </div>
                        </a>
                    </article>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        <?php endif; ?>

        
        <?php if(method_exists($posts, 'links')): ?>
            <div class="mt-12"><?php echo e($posts->withQueryString()->links()); ?></div>
        <?php endif; ?>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal386dc8449d6925e995096d9b8aa1f23d)): ?>
<?php $attributes = $__attributesOriginal386dc8449d6925e995096d9b8aa1f23d; ?>
<?php unset($__attributesOriginal386dc8449d6925e995096d9b8aa1f23d); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal386dc8449d6925e995096d9b8aa1f23d)): ?>
<?php $component = $__componentOriginal386dc8449d6925e995096d9b8aa1f23d; ?>
<?php unset($__componentOriginal386dc8449d6925e995096d9b8aa1f23d); ?>
<?php endif; ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', [
    'title' => 'Stories & News',
    'description' => 'Stories of hope, healing, and impact from CHJ Foundation programs across Nigeria.',
], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Bridges\Herd\chj\resources\views/pages/blog/index.blade.php ENDPATH**/ ?>

<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['events' => []]));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['events' => []]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>

<?php if (isset($component)) { $__componentOriginal386dc8449d6925e995096d9b8aa1f23d = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal386dc8449d6925e995096d9b8aa1f23d = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.ui.section','data' => ['bg' => 'muted','spacing' => 'default']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('ui.section'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['bg' => 'muted','spacing' => 'default']); ?>
    <div class="container-prose">
        <div class="flex flex-col gap-4 sm:flex-row sm:items-end sm:justify-between">
            <?php if (isset($component)) { $__componentOriginalfdf68e90b8911e1acb34fb0a05efc30f = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalfdf68e90b8911e1acb34fb0a05efc30f = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.ui.section-heading','data' => ['eyebrow' => 'What\'s Next','title' => 'Upcoming events & gatherings','intro' => 'Join us in person or in prayer — every gathering is an open invitation.']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('ui.section-heading'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['eyebrow' => 'What\'s Next','title' => 'Upcoming events & gatherings','intro' => 'Join us in person or in prayer — every gathering is an open invitation.']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalfdf68e90b8911e1acb34fb0a05efc30f)): ?>
<?php $attributes = $__attributesOriginalfdf68e90b8911e1acb34fb0a05efc30f; ?>
<?php unset($__attributesOriginalfdf68e90b8911e1acb34fb0a05efc30f); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalfdf68e90b8911e1acb34fb0a05efc30f)): ?>
<?php $component = $__componentOriginalfdf68e90b8911e1acb34fb0a05efc30f; ?>
<?php unset($__componentOriginalfdf68e90b8911e1acb34fb0a05efc30f); ?>
<?php endif; ?>
            <div class="hidden sm:block">
                <?php if (isset($component)) { $__componentOriginal66c7b838b6637afea57011f529ebd64b = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal66c7b838b6637afea57011f529ebd64b = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.ui.link-arrow','data' => ['href' => ''.e(route('events.index')).'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('ui.link-arrow'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['href' => ''.e(route('events.index')).'']); ?>All events <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal66c7b838b6637afea57011f529ebd64b)): ?>
<?php $attributes = $__attributesOriginal66c7b838b6637afea57011f529ebd64b; ?>
<?php unset($__attributesOriginal66c7b838b6637afea57011f529ebd64b); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal66c7b838b6637afea57011f529ebd64b)): ?>
<?php $component = $__componentOriginal66c7b838b6637afea57011f529ebd64b; ?>
<?php unset($__componentOriginal66c7b838b6637afea57011f529ebd64b); ?>
<?php endif; ?>
            </div>
        </div>

        <?php if(count($events) > 0): ?>
            <div class="mt-12 grid gap-6 lg:grid-cols-3 lg:gap-8">
                <?php $__currentLoopData = $events; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $event): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <article
                        x-data="reveal(<?php echo e($i * 80); ?>)"
                        x-intersect.once="onIntersect()"
                        class="fade-up flex flex-col rounded-2xl bg-white p-6 shadow-card ring-1 ring-stone-200/60 transition-all hover:shadow-lifted"
                    >
                        <div class="flex items-center gap-3">
                            <div class="flex h-14 w-14 flex-col items-center justify-center rounded-xl bg-brand-50 text-brand-700 ring-1 ring-brand-100">
                                <span class="text-[10px] font-semibold uppercase"><?php echo e(\Carbon\Carbon::parse($event->start_date)->format('M')); ?></span>
                                <span class="font-display text-xl font-semibold leading-none"><?php echo e(\Carbon\Carbon::parse($event->start_date)->format('j')); ?></span>
                            </div>
                            <div class="flex-1">
                                <span class="inline-block rounded-full bg-stone-100 px-2 py-0.5 text-[10px] font-semibold uppercase tracking-widest text-stone-600">
                                    <?php echo e($event->category); ?>

                                </span>
                                <p class="mt-1 text-xs text-stone-500"><?php echo e(\Carbon\Carbon::parse($event->start_date)->format('l, g:i A')); ?> · <?php echo e($event->location); ?></p>
                            </div>
                        </div>
                        <h3 class="mt-4 font-display text-lg font-semibold text-stone-900"><?php echo e($event->title); ?></h3>
                        <p class="mt-2 flex-1 text-sm text-stone-600"><?php echo e($event->excerpt); ?></p>
                        <a href="<?php echo e(route('events.show', $event)); ?>" class="mt-4 inline-flex items-center gap-1 text-sm font-semibold text-brand-700 hover:text-brand-800">
                            View details
                            <svg class="h-3.5 w-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24" stroke-width="2.5"><path stroke-linecap="round" stroke-linejoin="round" d="M17 8l4 4m0 0l-4 4m4-4H3"/></svg>
                        </a>
                    </article>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        <?php else: ?>
            <div class="mt-12 rounded-2xl bg-white p-8 text-center ring-1 ring-stone-200/60">
                <p class="text-sm text-stone-500">No events scheduled at the moment. Check back soon — or subscribe to our newsletter below.</p>
            </div>
        <?php endif; ?>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal386dc8449d6925e995096d9b8aa1f23d)): ?>
<?php $attributes = $__attributesOriginal386dc8449d6925e995096d9b8aa1f23d; ?>
<?php unset($__attributesOriginal386dc8449d6925e995096d9b8aa1f23d); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal386dc8449d6925e995096d9b8aa1f23d)): ?>
<?php $component = $__componentOriginal386dc8449d6925e995096d9b8aa1f23d; ?>
<?php unset($__componentOriginal386dc8449d6925e995096d9b8aa1f23d); ?>
<?php endif; ?>
<?php /**PATH C:\Users\Bridges\Herd\chj\resources\views/components/sections/events-preview.blade.php ENDPATH**/ ?>
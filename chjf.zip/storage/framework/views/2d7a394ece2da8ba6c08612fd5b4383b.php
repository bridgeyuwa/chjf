<?php
    $stats = [
        ['value' => '148,000+', 'label' => 'Meals served', 'sublabel' => 'Across Abuja, Niger & Plateau states', 'icon' => 'meal', 'tone' => 'brand'],
        ['value' => '1,250',    'label' => 'Families sheltered', 'sublabel' => 'Emergency & transitional housing', 'icon' => 'home', 'tone' => 'spark'],
        ['value' => '890',      'label' => 'Students in education', 'sublabel' => 'Scholarships + after-school', 'icon' => 'book', 'tone' => 'brand'],
        ['value' => '320',      'label' => 'Trafficking survivors', 'sublabel' => 'Since 2019', 'icon' => 'shield', 'tone' => 'brand'],
        ['value' => '4,200',    'label' => 'Medical consultations', 'sublabel' => 'Free community clinics, 2024', 'icon' => 'stethoscope', 'tone' => 'spark'],
        ['value' => '680',      'label' => 'Jobs placed & trained', 'sublabel' => 'Pathways graduates employed', 'icon' => 'briefcase', 'tone' => 'brand'],
        ['value' => '340',      'label' => 'Active volunteers', 'sublabel' => 'Serving weekly across programs', 'icon' => 'users', 'tone' => 'brand'],
        ['value' => '1,150',    'label' => 'Youth mentored', 'sublabel' => 'Bright Futures mentorship', 'icon' => 'heart', 'tone' => 'spark'],
    ];
?>

<?php if (isset($component)) { $__componentOriginal386dc8449d6925e995096d9b8aa1f23d = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal386dc8449d6925e995096d9b8aa1f23d = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.ui.section','data' => ['bg' => 'muted','spacing' => 'default']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('ui.section'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['bg' => 'muted','spacing' => 'default']); ?>
    <div class="container-prose">
        <?php if (isset($component)) { $__componentOriginalfdf68e90b8911e1acb34fb0a05efc30f = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalfdf68e90b8911e1acb34fb0a05efc30f = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.ui.section-heading','data' => ['eyebrow' => 'Our Impact','title' => 'Lives changed, one act of compassion at a time','intro' => 'Numbers are not the point — people are. But these figures represent real meals eaten, real children back in school, real survivors reunited with family.']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('ui.section-heading'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['eyebrow' => 'Our Impact','title' => 'Lives changed, one act of compassion at a time','intro' => 'Numbers are not the point — people are. But these figures represent real meals eaten, real children back in school, real survivors reunited with family.']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalfdf68e90b8911e1acb34fb0a05efc30f)): ?>
<?php $attributes = $__attributesOriginalfdf68e90b8911e1acb34fb0a05efc30f; ?>
<?php unset($__attributesOriginalfdf68e90b8911e1acb34fb0a05efc30f); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalfdf68e90b8911e1acb34fb0a05efc30f)): ?>
<?php $component = $__componentOriginalfdf68e90b8911e1acb34fb0a05efc30f; ?>
<?php unset($__componentOriginalfdf68e90b8911e1acb34fb0a05efc30f); ?>
<?php endif; ?>

        <div class="mt-12 grid grid-cols-2 gap-x-6 gap-y-10 sm:grid-cols-3 lg:grid-cols-4 lg:gap-x-8">
            <?php $__currentLoopData = $stats; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $stat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if (isset($component)) { $__componentOriginal01e87901d1d4257641ca1465090a996e = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal01e87901d1d4257641ca1465090a996e = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.ui.stat','data' => ['value' => $stat['value'],'label' => $stat['label'],'sublabel' => $stat['sublabel'],'icon' => $stat['icon'],'tone' => $stat['tone']]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('ui.stat'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($stat['value']),'label' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($stat['label']),'sublabel' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($stat['sublabel']),'icon' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($stat['icon']),'tone' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($stat['tone'])]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal01e87901d1d4257641ca1465090a996e)): ?>
<?php $attributes = $__attributesOriginal01e87901d1d4257641ca1465090a996e; ?>
<?php unset($__attributesOriginal01e87901d1d4257641ca1465090a996e); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal01e87901d1d4257641ca1465090a996e)): ?>
<?php $component = $__componentOriginal01e87901d1d4257641ca1465090a996e; ?>
<?php unset($__componentOriginal01e87901d1d4257641ca1465090a996e); ?>
<?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>

        <div class="mt-12 flex justify-center">
            <?php if (isset($component)) { $__componentOriginala8bb031a483a05f647cb99ed3a469847 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginala8bb031a483a05f647cb99ed3a469847 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.ui.button','data' => ['variant' => 'outline','size' => 'md','href' => ''.e(route('impact-report')).'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('ui.button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['variant' => 'outline','size' => 'md','href' => ''.e(route('impact-report')).'']); ?>
                Read the 2024 Impact Report
             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginala8bb031a483a05f647cb99ed3a469847)): ?>
<?php $attributes = $__attributesOriginala8bb031a483a05f647cb99ed3a469847; ?>
<?php unset($__attributesOriginala8bb031a483a05f647cb99ed3a469847); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala8bb031a483a05f647cb99ed3a469847)): ?>
<?php $component = $__componentOriginala8bb031a483a05f647cb99ed3a469847; ?>
<?php unset($__componentOriginala8bb031a483a05f647cb99ed3a469847); ?>
<?php endif; ?>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal386dc8449d6925e995096d9b8aa1f23d)): ?>
<?php $attributes = $__attributesOriginal386dc8449d6925e995096d9b8aa1f23d; ?>
<?php unset($__attributesOriginal386dc8449d6925e995096d9b8aa1f23d); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal386dc8449d6925e995096d9b8aa1f23d)): ?>
<?php $component = $__componentOriginal386dc8449d6925e995096d9b8aa1f23d; ?>
<?php unset($__componentOriginal386dc8449d6925e995096d9b8aa1f23d); ?>
<?php endif; ?>
<?php /**PATH C:\Users\Bridges\Herd\chj\resources\views/components/sections/impact-stats.blade.php ENDPATH**/ ?>
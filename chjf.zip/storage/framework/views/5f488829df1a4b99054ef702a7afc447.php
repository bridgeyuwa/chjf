<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames(([
    'eyebrow' => null,
    'title' => null,
    'intro' => null,
    'align' => 'left',  // left | center
    'tone' => 'dark',   // dark | light (for dark backgrounds)
]));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter(([
    'eyebrow' => null,
    'title' => null,
    'intro' => null,
    'align' => 'left',  // left | center
    'tone' => 'dark',   // dark | light (for dark backgrounds)
]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>

<?php
    $aligns = [
        'left'   => 'text-left',
        'center' => 'text-center mx-auto',
    ];
    $isLight = $tone === 'light';
    $titleColor = $isLight ? 'text-white' : 'text-stone-900';
    $introColor = $isLight ? 'text-stone-300' : 'text-stone-600';
    $eyebrowClass = $isLight ? 'text-brand-200' : 'text-brand-700';
?>

<div class="max-w-2xl <?php echo e($aligns[$align] ?? $aligns['left']); ?>"
     x-data="reveal"
     x-intersect.once="onIntersect()"
     class="fade-up">
    <?php if($eyebrow): ?>
        <span class="eyebrow <?php echo e($eyebrowClass); ?>"><?php echo e($eyebrow); ?></span>
    <?php endif; ?>
    <?php if($title): ?>
        <h2 class="mt-3 font-display text-3xl font-semibold tracking-tight sm:text-4xl lg:text-5xl <?php echo e($titleColor); ?>">
            <?php echo e($title); ?>

        </h2>
    <?php endif; ?>
    <?php if($intro): ?>
        <p class="mt-4 text-lg leading-relaxed <?php echo e($introColor); ?>"><?php echo e($intro); ?></p>
    <?php endif; ?>
    <?php echo e($slot); ?>

</div>
<?php /**PATH C:\Users\Bridges\Herd\chj\resources\views/components/ui/section-heading.blade.php ENDPATH**/ ?>
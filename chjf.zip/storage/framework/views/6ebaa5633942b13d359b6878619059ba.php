<?php
    $programs = [
        [
            'slug' => 'hope-kitchen',
            'name' => 'Hope Kitchen',
            'tag' => 'Food Security',
            'desc' => 'Hot meals, dry rations, and emergency food parcels for families facing hunger across Abuja and surrounding states.',
            'img' => 'https://images.unsplash.com/photo-1488521787991-ed7bbaae773c?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80',
            'stat' => '148,000+ meals served',
            'icon' => 'meal',
            'accent' => 'bg-amber-50 text-amber-700 ring-amber-200',
        ],
        [
            'slug' => 'safe-harbor',
            'name' => 'Safe Harbor',
            'tag' => 'Anti-Trafficking',
            'desc' => 'Rescue, recovery, and reintegration support for survivors of human trafficking and modern slavery.',
            'img' => 'https://images.unsplash.com/photo-1521791136064-7986c2920216?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80',
            'stat' => '320 survivors supported',
            'icon' => 'shield',
            'accent' => 'bg-rose-50 text-rose-700 ring-rose-200',
        ],
        [
            'slug' => 'pathways',
            'name' => 'Pathways',
            'tag' => 'Education & Jobs',
            'desc' => 'Scholarships, vocational training, and job placement for young people ready to build a future.',
            'img' => 'https://images.unsplash.com/photo-1497486751825-1233686d5d80?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80',
            'stat' => '680 graduates employed',
            'icon' => 'book',
            'accent' => 'bg-sky-50 text-sky-700 ring-sky-200',
        ],
        [
            'slug' => 'healing-hands',
            'name' => 'Healing Hands',
            'tag' => 'Medical Care',
            'desc' => 'Free community clinics, maternal care, and emergency medical assistance for those without access.',
            'img' => 'https://images.unsplash.com/photo-1576091160550-2173dba999ef?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80',
            'stat' => '4,200 consultations in 2024',
            'icon' => 'stethoscope',
            'accent' => 'bg-emerald-50 text-emerald-700 ring-emerald-200',
        ],
        [
            'slug' => 'bright-futures',
            'name' => 'Bright Futures',
            'tag' => 'Youth Mentorship',
            'desc' => 'One-to-one mentorship, life skills, and faith formation for young people aged 10–18.',
            'img' => 'https://images.unsplash.com/photo-1509062522246-3755977927d7?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80',
            'stat' => '1,150 youth mentored',
            'icon' => 'users',
            'accent' => 'bg-brand-50 text-brand-700 ring-brand-200',
        ],
        [
            'slug' => 'community-care',
            'name' => 'Community Care',
            'tag' => 'Housing & Shelter',
            'desc' => 'Emergency shelter for families in crisis, plus longer-term transitional housing support.',
            'img' => 'https://images.unsplash.com/photo-1505739679850-7adfa1f7fbcc?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80',
            'stat' => '1,250 families sheltered',
            'icon' => 'home',
            'accent' => 'bg-stone-100 text-stone-700 ring-stone-200',
        ],
    ];
?>

<?php if (isset($component)) { $__componentOriginal386dc8449d6925e995096d9b8aa1f23d = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal386dc8449d6925e995096d9b8aa1f23d = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.ui.section','data' => ['bg' => 'white','spacing' => 'default']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('ui.section'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['bg' => 'white','spacing' => 'default']); ?>
    <div class="container-prose">
        <div class="flex flex-col gap-4 sm:flex-row sm:items-end sm:justify-between">
            <?php if (isset($component)) { $__componentOriginalfdf68e90b8911e1acb34fb0a05efc30f = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalfdf68e90b8911e1acb34fb0a05efc30f = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.ui.section-heading','data' => ['eyebrow' => 'What We Do','title' => 'Six programs. One mission.','intro' => 'Each program is rooted in the conviction that every person bears the image of God — and deserves to be treated as such.']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('ui.section-heading'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['eyebrow' => 'What We Do','title' => 'Six programs. One mission.','intro' => 'Each program is rooted in the conviction that every person bears the image of God — and deserves to be treated as such.']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalfdf68e90b8911e1acb34fb0a05efc30f)): ?>
<?php $attributes = $__attributesOriginalfdf68e90b8911e1acb34fb0a05efc30f; ?>
<?php unset($__attributesOriginalfdf68e90b8911e1acb34fb0a05efc30f); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalfdf68e90b8911e1acb34fb0a05efc30f)): ?>
<?php $component = $__componentOriginalfdf68e90b8911e1acb34fb0a05efc30f; ?>
<?php unset($__componentOriginalfdf68e90b8911e1acb34fb0a05efc30f); ?>
<?php endif; ?>
            <div class="hidden sm:block">
                <?php if (isset($component)) { $__componentOriginal66c7b838b6637afea57011f529ebd64b = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal66c7b838b6637afea57011f529ebd64b = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.ui.link-arrow','data' => ['href' => ''.e(route('programs.index')).'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('ui.link-arrow'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['href' => ''.e(route('programs.index')).'']); ?>All programs <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal66c7b838b6637afea57011f529ebd64b)): ?>
<?php $attributes = $__attributesOriginal66c7b838b6637afea57011f529ebd64b; ?>
<?php unset($__attributesOriginal66c7b838b6637afea57011f529ebd64b); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal66c7b838b6637afea57011f529ebd64b)): ?>
<?php $component = $__componentOriginal66c7b838b6637afea57011f529ebd64b; ?>
<?php unset($__componentOriginal66c7b838b6637afea57011f529ebd64b); ?>
<?php endif; ?>
            </div>
        </div>

        <div class="mt-12 grid gap-6 sm:grid-cols-2 lg:grid-cols-3 lg:gap-8">
            <?php $__currentLoopData = $programs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $program): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <a
                    href="<?php echo e(route('programs.show', $program['slug'])); ?>"
                    x-data="reveal(<?php echo e($i * 80); ?>)"
                    x-intersect.once="onIntersect()"
                    class="fade-up group flex flex-col overflow-hidden rounded-2xl bg-white shadow-card ring-1 ring-stone-200/60 transition-all duration-300 hover:-translate-y-1 hover:shadow-lifted"
                >
                    <div class="relative aspect-[3/2] overflow-hidden">
                        <img
                            src="<?php echo e($program['img']); ?>"
                            alt="<?php echo e($program['name']); ?>"
                            loading="lazy"
                            class="h-full w-full object-cover transition-transform duration-500 group-hover:scale-105"
                        />
                        <div class="absolute inset-0 bg-gradient-to-t from-stone-900/50 via-transparent to-transparent"></div>
                        <span class="absolute left-3 top-3 inline-flex items-center rounded-full bg-white/95 px-2.5 py-1 text-[10px] font-semibold uppercase tracking-widest text-stone-700 shadow-soft backdrop-blur">
                            <?php echo e($program['tag']); ?>

                        </span>
                    </div>
                    <div class="flex flex-1 flex-col p-6">
                        <h3 class="font-display text-xl font-semibold text-stone-900 group-hover:text-brand-700"><?php echo e($program['name']); ?></h3>
                        <p class="mt-2 flex-1 text-sm leading-relaxed text-stone-600"><?php echo e($program['desc']); ?></p>
                        <div class="mt-5 flex items-center justify-between border-t border-stone-100 pt-4">
                            <span class="text-xs font-semibold text-brand-700"><?php echo e($program['stat']); ?></span>
                            <span class="inline-flex items-center gap-1 text-xs font-semibold text-stone-500 group-hover:text-brand-700">
                                Learn more
                                <svg class="h-3.5 w-3.5 transition-transform group-hover:translate-x-0.5" fill="none" stroke="currentColor" viewBox="0 0 24 24" stroke-width="2.5"><path stroke-linecap="round" stroke-linejoin="round" d="M17 8l4 4m0 0l-4 4m4-4H3"/></svg>
                            </span>
                        </div>
                    </div>
                </a>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>

        <div class="mt-10 flex justify-center sm:hidden">
            <?php if (isset($component)) { $__componentOriginala8bb031a483a05f647cb99ed3a469847 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginala8bb031a483a05f647cb99ed3a469847 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.ui.button','data' => ['variant' => 'outline','href' => ''.e(route('programs.index')).'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('ui.button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['variant' => 'outline','href' => ''.e(route('programs.index')).'']); ?>All programs <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginala8bb031a483a05f647cb99ed3a469847)): ?>
<?php $attributes = $__attributesOriginala8bb031a483a05f647cb99ed3a469847; ?>
<?php unset($__attributesOriginala8bb031a483a05f647cb99ed3a469847); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala8bb031a483a05f647cb99ed3a469847)): ?>
<?php $component = $__componentOriginala8bb031a483a05f647cb99ed3a469847; ?>
<?php unset($__componentOriginala8bb031a483a05f647cb99ed3a469847); ?>
<?php endif; ?>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal386dc8449d6925e995096d9b8aa1f23d)): ?>
<?php $attributes = $__attributesOriginal386dc8449d6925e995096d9b8aa1f23d; ?>
<?php unset($__attributesOriginal386dc8449d6925e995096d9b8aa1f23d); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal386dc8449d6925e995096d9b8aa1f23d)): ?>
<?php $component = $__componentOriginal386dc8449d6925e995096d9b8aa1f23d; ?>
<?php unset($__componentOriginal386dc8449d6925e995096d9b8aa1f23d); ?>
<?php endif; ?>
<?php /**PATH C:\Users\Bridges\Herd\chj\resources\views/components/sections/programs-preview.blade.php ENDPATH**/ ?>
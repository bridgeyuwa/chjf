<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames(([
    'variant' => 'default',  // default | muted | brand | dark
    'as' => 'div',
    'padding' => 'default',  // default | tight | none
]));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter(([
    'variant' => 'default',  // default | muted | brand | dark
    'as' => 'div',
    'padding' => 'default',  // default | tight | none
]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>

<?php
    $variants = [
        'default' => 'bg-white ring-1 ring-stone-200/60 shadow-card',
        'muted'   => 'bg-stone-50 ring-1 ring-stone-200/60',
        'brand'   => 'bg-brand-50 ring-1 ring-brand-200/60',
        'dark'    => 'bg-stone-900 ring-1 ring-stone-800 text-white',
    ];
    $paddings = [
        'default' => 'p-6 sm:p-8',
        'tight'   => 'p-4 sm:p-5',
        'none'    => '',
    ];
    $classes = 'rounded-2xl ' . ($variants[$variant] ?? $variants['default']) . ' ' . ($paddings[$padding] ?? $paddings['default']);
?>

<<?php echo e($as); ?> <?php echo e($attributes->merge(['class' => $classes])); ?>>
    <?php echo e($slot); ?>

</<?php echo e($as); ?>>
<?php /**PATH C:\Users\Bridges\Herd\chj\resources\views/components/ui/card.blade.php ENDPATH**/ ?>
<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames(([
    'src' => null,
    'alt' => '',
    'ratio' => '4/3',  // 4/3 | 16/9 | 1/1 | 3/2 | 3/4
    'rounded' => '2xl',
    'overlay' => false,  // add subtle bottom-up gradient overlay
]));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter(([
    'src' => null,
    'alt' => '',
    'ratio' => '4/3',  // 4/3 | 16/9 | 1/1 | 3/2 | 3/4
    'rounded' => '2xl',
    'overlay' => false,  // add subtle bottom-up gradient overlay
]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>

<?php
    $ratios = [
        '4/3'  => 'aspect-[4/3]',
        '16/9' => 'aspect-[16/9]',
        '1/1'  => 'aspect-square',
        '3/2'  => 'aspect-[3/2]',
        '3/4'  => 'aspect-[3/4]',
    ];
    $roundedClass = 'rounded-' . $rounded;
?>

<div class="overflow-hidden <?php echo e($roundedClass); ?> bg-stone-100 ring-1 ring-stone-200/60 <?php echo e($ratios[$ratio] ?? $ratios['4/3']); ?> <?php echo e($attributes->get('class')); ?>">
    <div class="relative h-full w-full">
        <img
            src="<?php echo e($src); ?>"
            alt="<?php echo e($alt); ?>"
            loading="lazy"
            decoding="async"
            class="h-full w-full object-cover"
        />
        <?php if($overlay): ?>
            <div class="absolute inset-0 bg-gradient-to-t from-stone-900/60 via-transparent to-transparent"></div>
        <?php endif; ?>
        <?php if(isset($caption)): ?>
            <figcaption class="absolute bottom-3 left-3 right-3 text-xs text-white/90"><?php echo e($caption); ?></figcaption>
        <?php endif; ?>
    </div>
</div>
<?php /**PATH C:\Users\Bridges\Herd\chj\resources\views/components/ui/image-frame.blade.php ENDPATH**/ ?>
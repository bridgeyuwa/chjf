<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames(([
    'bg' => 'white',  // white | muted | brand | dark | gradient
    'spacing' => 'default',  // default | tight | none
    'id' => null,
    'class' => '',
]));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter(([
    'bg' => 'white',  // white | muted | brand | dark | gradient
    'spacing' => 'default',  // default | tight | none
    'id' => null,
    'class' => '',
]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>

<?php
    $bgs = [
        'white'    => 'bg-white',
        'muted'    => 'bg-stone-50',
        'brand'    => 'bg-brand-50',
        'dark'     => 'bg-stone-900 text-stone-300',
        'gradient' => 'bg-gradient-to-br from-brand-700 via-brand-800 to-brand-950 text-white',
    ];
    $spacings = [
        'default' => 'py-16 sm:py-20 lg:py-28',
        'tight'   => 'py-12 sm:py-16 lg:py-20',
        'none'    => '',
    ];
    $classes = $bgs[$bg] . ' ' . $spacings[$spacing] . ' ' . $class;
?>

<section id="<?php echo e($id); ?>" class="<?php echo e($classes); ?>">
    <?php echo e($slot); ?>

</section>
<?php /**PATH C:\Users\Bridges\Herd\chj\resources\views/components/ui/section.blade.php ENDPATH**/ ?>
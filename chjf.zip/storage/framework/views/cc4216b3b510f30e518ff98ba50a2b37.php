<?php $__env->startSection('content'); ?>

<?php if (isset($component)) { $__componentOriginalc2ac24e8b26a95c4ab17f6ffff7eecc8 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalc2ac24e8b26a95c4ab17f6ffff7eecc8 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.ui.page-hero','data' => ['eyebrow' => 'Gallery','title' => 'Faces of the work.','intro' => 'Real people, real moments, real compassion. A photo essay from our programs across Abuja, Niger, and Plateau states.']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('ui.page-hero'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['eyebrow' => 'Gallery','title' => 'Faces of the work.','intro' => 'Real people, real moments, real compassion. A photo essay from our programs across Abuja, Niger, and Plateau states.']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalc2ac24e8b26a95c4ab17f6ffff7eecc8)): ?>
<?php $attributes = $__attributesOriginalc2ac24e8b26a95c4ab17f6ffff7eecc8; ?>
<?php unset($__attributesOriginalc2ac24e8b26a95c4ab17f6ffff7eecc8); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc2ac24e8b26a95c4ab17f6ffff7eecc8)): ?>
<?php $component = $__componentOriginalc2ac24e8b26a95c4ab17f6ffff7eecc8; ?>
<?php unset($__componentOriginalc2ac24e8b26a95c4ab17f6ffff7eecc8); ?>
<?php endif; ?>

<?php if (isset($component)) { $__componentOriginal386dc8449d6925e995096d9b8aa1f23d = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal386dc8449d6925e995096d9b8aa1f23d = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.ui.section','data' => ['bg' => 'white','spacing' => 'default']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('ui.section'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['bg' => 'white','spacing' => 'default']); ?>
    <div class="container-prose">

        
        <div class="flex flex-wrap gap-2 border-b border-stone-200 pb-6">
            <?php $__currentLoopData = ['All', 'Hope Kitchen', 'Safe Harbor', 'Pathways', 'Healing Hands', 'Bright Futures', 'Events']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <a href="?program=<?php echo e(urlencode(strtolower($cat))); ?>"
                   class="rounded-full px-3 py-1.5 text-xs font-semibold uppercase tracking-widest transition-colors
                   <?php if(request('program', 'all') === strtolower($cat) || ($i === 0 && !request('program'))): ?>
                       bg-brand-600 text-white shadow-soft
                   <?php else: ?>
                       bg-stone-100 text-stone-700 hover:bg-brand-100 hover:text-brand-700
                   <?php endif; ?>">
                    <?php echo e($cat); ?>

                </a>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>

        <?php
            $photos = [
                ['src' => 'https://images.unsplash.com/photo-1488521787991-ed7bbaae773c?ixlib=rb-4.0.3&auto=format&fit=crop&w=900&q=80', 'alt' => 'Hope Kitchen — Saturday meal service', 'caption' => 'Saturday meal service · Jabi', 'span' => 'lg:col-span-2'],
                ['src' => 'https://images.unsplash.com/photo-1593113598332-cd288d649433?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&q=80', 'alt' => 'Children with bowls of food', 'caption' => 'Children receiving meals', 'span' => ''],
                ['src' => 'https://images.unsplash.com/photo-1509062522246-3755977927d7?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&q=80', 'alt' => 'Youth mentorship session', 'caption' => 'Bright Futures mentorship', 'span' => ''],
                ['src' => 'https://images.unsplash.com/photo-1497486751825-1233686d5d80?ixlib=rb-4.0.3&auto=format&fit=crop&w=900&q=80', 'alt' => 'Pathways classroom', 'caption' => 'Pathways vocational training', 'span' => 'lg:col-span-2'],
                ['src' => 'https://images.unsplash.com/photo-1576091160550-2173dba999ef?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&q=80', 'alt' => 'Healing Hands clinic', 'caption' => 'Healing Hands clinic · Nyanya', 'span' => ''],
                ['src' => 'https://images.unsplash.com/photo-1559757148-5c350d0d3c56?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&q=80', 'alt' => 'Mobile medical clinic', 'caption' => 'Mobile clinic · Niger State', 'span' => ''],
                ['src' => 'https://images.unsplash.com/photo-1521791136064-7986c2920216?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&q=80', 'alt' => 'Counseling session', 'caption' => 'Safe Harbor counseling', 'span' => ''],
                ['src' => 'https://images.unsplash.com/photo-1530541930197-ff16ac917b0e?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&q=80', 'alt' => 'Group session', 'caption' => 'Youth group session', 'span' => ''],
                ['src' => 'https://images.unsplash.com/photo-1607582544185-66fdfaee69ad?ixlib=rb-4.0.3&auto=format&fit=crop&w=900&q=80', 'alt' => 'Dry ration distribution', 'caption' => 'Dry ration distribution · Gwarinpa', 'span' => 'lg:col-span-2'],
                ['src' => 'https://images.unsplash.com/photo-1572177812156-58036aae439c?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&q=80', 'alt' => 'Tailoring workshop', 'caption' => 'Pathways tailoring workshop', 'span' => ''],
                ['src' => 'https://images.unsplash.com/photo-1581091226825-a6a2a5aee158?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&q=80', 'alt' => 'IT training', 'caption' => 'Pathways IT training', 'span' => ''],
                ['src' => 'https://images.unsplash.com/photo-1517457373958-b7bdd4587205?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&q=80', 'alt' => 'Holiday camp', 'caption' => 'Bright Futures holiday camp', 'span' => ''],
            ];
        ?>

        <div class="mt-10 grid grid-cols-2 gap-4 sm:gap-6 lg:grid-cols-4">
            <?php $__currentLoopData = $photos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $photo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <figure
                    x-data="reveal(<?php echo e(($i % 4) * 80); ?>)"
                    x-intersect.once="onIntersect()"
                    class="fade-up group relative overflow-hidden rounded-2xl bg-stone-100 shadow-card <?php echo e($photo['span'] ?? ''); ?>"
                >
                    <img src="<?php echo e($photo['src']); ?>" alt="<?php echo e($photo['alt']); ?>" loading="lazy" class="aspect-[4/3] h-full w-full object-cover transition-transform duration-500 group-hover:scale-105"/>
                    <figcaption class="absolute inset-x-0 bottom-0 bg-gradient-to-t from-stone-900/80 to-transparent p-4 text-xs text-white opacity-0 transition-opacity group-hover:opacity-100">
                        <?php echo e($photo['caption']); ?>

                    </figcaption>
                </figure>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>

        <p class="mt-10 text-center text-xs text-stone-500">
            All photos used are royalty-free Unsplash imagery used as placeholders. Real CHJ Foundation photography to be added before launch. Privacy and dignity of those we serve is paramount in our photo policy.
        </p>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal386dc8449d6925e995096d9b8aa1f23d)): ?>
<?php $attributes = $__attributesOriginal386dc8449d6925e995096d9b8aa1f23d; ?>
<?php unset($__attributesOriginal386dc8449d6925e995096d9b8aa1f23d); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal386dc8449d6925e995096d9b8aa1f23d)): ?>
<?php $component = $__componentOriginal386dc8449d6925e995096d9b8aa1f23d; ?>
<?php unset($__componentOriginal386dc8449d6925e995096d9b8aa1f23d); ?>
<?php endif; ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', [
    'title' => 'Gallery',
    'description' => 'Photos from CHJ Foundation programs across Nigeria — Hope Kitchen, Safe Harbor, Pathways, Healing Hands, and Bright Futures.',
], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Bridges\Herd\chj\resources\views/pages/gallery.blade.php ENDPATH**/ ?>
<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames(([
    'label' => null,
    'name' => null,
    'type' => 'text',
    'required' => false,
    'placeholder' => null,
    'autocomplete' => null,
    'hint' => null,
    'value' => null,
]));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter(([
    'label' => null,
    'name' => null,
    'type' => 'text',
    'required' => false,
    'placeholder' => null,
    'autocomplete' => null,
    'hint' => null,
    'value' => null,
]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>

<?php
    $name = $name ?? str($label)->snake()->lower();
    $id = 'field-' . str($name)->slug();
    $hasError = $errors->has($name);
    $error = $errors->first($name);
    $oldVal = old($name, $value);
?>

<div x-data="{ field: '<?php echo e($name); ?>' }" class="w-full">
    <?php if($label): ?>
        <label for="<?php echo e($id); ?>" class="block text-sm font-medium text-stone-800">
            <?php echo e($label); ?>

            <?php if($required): ?><span class="text-rose-500" aria-hidden="true">*</span><?php endif; ?>
        </label>
    <?php endif; ?>

    <input
        id="<?php echo e($id); ?>"
        name="<?php echo e($name); ?>"
        type="<?php echo e($type); ?>"
        value="<?php echo e($oldVal); ?>"
        placeholder="<?php echo e($placeholder); ?>"
        autocomplete="<?php echo e($autocomplete); ?>"
        <?php if($required): ?> required <?php endif; ?>
        <?php if($hasError): ?> aria-invalid="true" aria-describedby="<?php echo e($id); ?>-error" <?php endif; ?>
        class="mt-1.5 block w-full rounded-lg border-0 bg-white px-3.5 py-2.5 text-stone-900 shadow-sm ring-1 ring-inset ring-stone-300 transition-all placeholder:text-stone-400 focus:ring-2 focus:ring-inset focus:ring-brand-500"
        :class="hasError('<?php echo e($name); ?>') ? 'ring-rose-400 focus:ring-rose-500' : ''"
        @blur="validateField('<?php echo e($name); ?>', '<?php echo e($required ? 'required' : ''); ?><?php echo e($type === 'email' ? '|email' : ''); ?><?php echo e($type === 'tel' ? '|phone' : ''); ?>')"
    />

    <?php if($hint && !$hasError): ?>
        <p class="mt-1.5 text-xs text-stone-500"><?php echo e($hint); ?></p>
    <?php endif; ?>

    <?php if($hasError): ?>
        <p id="<?php echo e($id); ?>-error" class="mt-1.5 flex items-center gap-1 text-xs text-rose-600">
            <svg class="h-3.5 w-3.5 flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24" stroke-width="2"><path stroke-linecap="round" stroke-linejoin="round" d="M12 9v3.75m9-.75a9 9 0 11-18 0 9 9 0 0118 0zm-9 3.75h.008v.008H12v-.008z"/></svg>
            <?php echo e($error); ?>

        </p>
    <?php endif; ?>
    <p x-show="hasError('<?php echo e($name); ?>')" x-cloak x-text="errors['<?php echo e($name); ?>']" class="mt-1.5 flex items-center gap-1 text-xs text-rose-600">
        <svg class="h-3.5 w-3.5 flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24" stroke-width="2"><path stroke-linecap="round" stroke-linejoin="round" d="M12 9v3.75m9-.75a9 9 0 11-18 0 9 9 0 0118 0zm-9 3.75h.008v.008H12v-.008z"/></svg>
    </p>
</div>
<?php /**PATH C:\Users\Bridges\Herd\chj\resources\views/components/ui/input.blade.php ENDPATH**/ ?>